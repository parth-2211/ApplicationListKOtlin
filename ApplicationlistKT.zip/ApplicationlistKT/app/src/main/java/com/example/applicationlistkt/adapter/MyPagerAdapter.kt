package com.example.applicationlistkt.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class MyPagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {

    private val appList = ArrayList<Fragment>()
    override fun getItemCount(): Int {
        return appList.size
    }

    override fun createFragment(position: Int): Fragment {
        return appList[position]
    }

    fun addFragment(fragment: Fragment) {
        appList.add(fragment)
    }
}