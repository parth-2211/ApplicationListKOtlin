package com.example.applicationlistkt

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.applicationlistkt.adapter.MyPagerAdapter
import com.example.applicationlistkt.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Date

class MainActivity : AppCompatActivity() {

    private lateinit var system: AppFragment
    private lateinit var install: AppFragment
    private lateinit var binding: ActivityMainBinding
    private var allAppModelList: ArrayList<AllAppListModel> = arrayListOf()
    private val loadedList = arrayListOf<AllAppListModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    /** this is just a function for the clean code structure */
    private fun init() {
        loadFragment()
    }

    /** that function is load the fragment in this activity */
    private fun loadFragment() {
        system = AppFragment.newInstance(AppFragment.APP_TYPE_SYSTEM)
        install = AppFragment.newInstance(AppFragment.APP_TYPE_INSTALL)
        val myPagerAdapter = MyPagerAdapter(this)
        myPagerAdapter.addFragment(system)
        myPagerAdapter.addFragment(install)
        binding.vpViewPager2.adapter = myPagerAdapter

        TabLayoutMediator(binding.tbTabLayout, binding.vpViewPager2) { tab, position ->
            when (position) {
                0 -> tab.text = SYSTEM_APP
                1 -> tab.text = INSTALL_APP
            }
        }.attach()

        loadData(AppFragment.APP_TYPE_SYSTEM)
        loadData(AppFragment.APP_TYPE_INSTALL)
    }

    /** this funcation is gives you a allAppModelList */
    fun getAllAppModelList(): List<AllAppListModel> {
        return allAppModelList
    }

    /** this code is send the data to AllAppDetailsActivity using Intent */
    fun openAppDetails(packageName: String) {
        val intent = Intent(this, AllAppDetailsActivity::class.java)
        intent.putExtra(EXTRA_PACKAGE_NAME, packageName)
        startActivityForResult(intent, REQUEST_CODE_APP_DETAILS)
    }

    /** this code shows you progress bar when the data is loading */
    private fun loadData(appType: Int) {
        binding.pbProgress.visibility = View.VISIBLE
        GlobalScope.launch(Dispatchers.Main) {
            val loadedAppList = withContext(Dispatchers.IO) {
                loadInstalledApps(appType)
            }
            allAppModelList.addAll(loadedAppList)

            if (appType == AppFragment.APP_TYPE_INSTALL) {
                install.updateData()
            } else if (appType == AppFragment.APP_TYPE_SYSTEM) {
                system.updateData()
            }
            binding.pbProgress.visibility = View.GONE
        }
    }

    /** this code is helps you to get the app info */
    private fun loadInstalledApps(appType: Int): List<AllAppListModel> {
        Log.e("TAG", "loadInstalledApps: ", )
        val list = packageManager?.getInstalledPackages(0)

        list?.let {
            for (i in it.indices) {
                val packageInfo = list[i]
                val appName =
                    packageManager?.getApplicationLabel(packageInfo.applicationInfo)?.toString()
                val packageName = packageInfo.packageName
                val appIcon = packageInfo.applicationInfo.loadIcon(packageManager)
                val appIcon1 = appIconToBitmap(appIcon)
                val installDate = Date(packageInfo.firstInstallTime)
                val updateDate = Date(packageInfo.lastUpdateTime)
                val version = packageInfo.versionName
                val appFlags = packageInfo.applicationInfo.flags

                val allModel = AllAppListModel(
                    appName.orEmpty(),
                    packageName,
                    appIcon1,
                    installDate,
                    updateDate,
                    version,
                    appFlags
                )

                if (appType == AppFragment.APP_TYPE_INSTALL && appFlags and ApplicationInfo.FLAG_SYSTEM == 0) {
                    loadedList.add(allModel)
                } else if (appType == AppFragment.APP_TYPE_SYSTEM && appFlags and ApplicationInfo.FLAG_SYSTEM != 0) {
                    if (isAppLaunched(packageName)) {
                        loadedList.add(allModel)
                    }
                }
            }
        }
        return loadedList
    }

    /** this code only show the launch Apps for system App */
    private fun isAppLaunched(packageName: String): Boolean {
        val launchIntent = packageManager?.getLaunchIntentForPackage(packageName)
        return launchIntent != null
    }

    /** this code is use for the change the app icon in drawable and give you bitmap */
    private fun appIconToBitmap(icon: Drawable): Bitmap {
        val width = icon.intrinsicWidth
        val height = icon.intrinsicHeight
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        icon.setBounds(0, 0, canvas.width, canvas.height)
        icon.draw(canvas)
        return bitmap
    }
}

