package com.example.applicationlistkt


const val SystemApp = "System App"
const val InstallApp = "Install App"
const val DateFormatDemo = "dd/MM/yyyy"
const val packageName = "extra_package_name"

const val REQUEST_CODE_APP_DETAILS = 1
const val EXTRA_PACKAGE_NAME = packageName

private const val ARG_APP_TYPE = "appType"
const val APP_TYPE_SYSTEM = 0
const val APP_TYPE_INSTALL = 1

const val SYSTEM_APP = "System App"
const val INSTALL_APP = "Install App"