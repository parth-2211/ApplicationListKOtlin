package com.example.applicationlistkt

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.applicationlistkt.databinding.ActivityAllAppDetailsBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AllAppDetailsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAllAppDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAllAppDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    /** In that function, get the intent and pass in the getPackageData function*/
    private fun init() {
        val packageName = intent.getStringExtra(EXTRA_PACKAGE_NAME) ?: ""
        getPackageData(packageName)
    }


    /** this function gives you the all data for show you in the detail screen */
    private fun getPackageData(packageName: String) {

        val packageManager = packageManager
        try {
            val packageInfo = packageManager.getPackageInfo(packageName, 0)
            val appName = packageInfo.applicationInfo.loadLabel(packageManager).toString()
            val appIconDrawable = packageInfo.applicationInfo.loadIcon(packageManager)
            val appIconBitmap: Bitmap? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                when (appIconDrawable) {
                    is BitmapDrawable -> appIconDrawable.bitmap
                    is AdaptiveIconDrawable -> {
                        val bitmapDrawable = BitmapDrawable(
                            resources,
                            Bitmap.createBitmap(
                                appIconDrawable.intrinsicWidth,
                                appIconDrawable.intrinsicHeight,
                                Bitmap.Config.ARGB_8888
                            )
                        )
                        val canvas = Canvas(bitmapDrawable.bitmap)
                        appIconDrawable.setBounds(0, 0, canvas.width, canvas.height)
                        appIconDrawable.draw(canvas)
                        bitmapDrawable.bitmap
                    }
                    else -> null
                }
            } else {
                null
            }

            val version = packageInfo.versionName
            val updateDate = packageInfo.lastUpdateTime
            val installDate = packageInfo.firstInstallTime

            /**
             * Set the retrieved data to the corresponding views
             */
            binding.tvMainAppName.text = appName
            binding.tvMainPackageName.text = packageName
            binding.tvMainInstallData.text =
                SimpleDateFormat(DateFormatDemo, Locale.getDefault()).format(Date(updateDate))
            binding.tvMainUpDate.text =
                SimpleDateFormat(DateFormatDemo, Locale.getDefault()).format(Date(installDate))
            binding.tvMainVersion.text = version

            /**
             * Set the app icon if available
             */
            appIconBitmap?.let {
                val drawable = BitmapDrawable(resources, it)
                binding.ivMainImageAppIcon.setImageDrawable(drawable)
            }
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }
    }
}