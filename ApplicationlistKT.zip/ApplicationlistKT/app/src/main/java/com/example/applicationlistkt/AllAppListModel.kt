package com.example.applicationlistkt

import android.graphics.Bitmap
import java.util.Date

data class AllAppListModel(
    val appName: String?,
    val packageName: String?,
    val appIcon1: Bitmap?,
    val installDate: Date?,
    val updateDate: Date?,
    val version: String?,
    val appFlags : Int
)
