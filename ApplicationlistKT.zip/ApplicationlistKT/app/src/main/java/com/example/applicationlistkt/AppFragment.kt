package com.example.applicationlistkt

import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.applicationlistkt.adapter.AppDataAdapter
import com.example.applicationlistkt.databinding.FragmentAppBinding

class AppFragment : Fragment() {
    private lateinit var binding: FragmentAppBinding
    private lateinit var appDataAdapter: AppDataAdapter
    private var appType: Int = APP_TYPE_SYSTEM

    companion object {
        private const val ARG_APP_TYPE = "appType"
        const val APP_TYPE_SYSTEM = 0
        const val APP_TYPE_INSTALL = 1

        fun newInstance(appType: Int): AppFragment {
            val fragment = AppFragment()
            val args = Bundle()
            args.putInt(ARG_APP_TYPE, appType)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentAppBinding.inflate(inflater, container, false)
        appDataAdapter = AppDataAdapter(context as MainActivity, ArrayList())
        binding.rvShowApp.adapter = appDataAdapter
        binding.rvShowApp.layoutManager = LinearLayoutManager(requireContext())

        appType = arguments?.getInt(ARG_APP_TYPE, APP_TYPE_SYSTEM) ?: APP_TYPE_SYSTEM
        updateData()

        return binding.root
    }

    /** this code update the adapter for set the data in model */
    fun updateData() {
        val mainActivity = activity as? MainActivity
        if (mainActivity != null && isAdded) {
            val allAppModelList = mainActivity.getAllAppModelList()
            val filteredAppList = filterAppList(allAppModelList)
            appDataAdapter.setData(filteredAppList as ArrayList<AllAppListModel>)
        }
    }

    /** this function is separate the system app and install app  */
    private fun filterAppList(allAppModelList: List<AllAppListModel>): List<AllAppListModel> {
        return allAppModelList.filter { appModel ->
            if (appType == APP_TYPE_INSTALL) {
                appModel.appFlags and ApplicationInfo.FLAG_SYSTEM == 0
            } else {
                appModel.appFlags and ApplicationInfo.FLAG_SYSTEM != 0
            }
        }
    }
}

