package com.example.applicationlistkt.adapter

import android.graphics.drawable.BitmapDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.applicationlistkt.AllAppListModel
import com.example.applicationlistkt.MainActivity
import com.example.applicationlistkt.databinding.LayoutShowHomeDetailsBinding

class AppDataAdapter(
    private var context: MainActivity,
    private var appList: ArrayList<AllAppListModel>
) : RecyclerView.Adapter<AppDataAdapter.MyViewHolder>() {

    inner class MyViewHolder(val binding: LayoutShowHomeDetailsBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(
            LayoutShowHomeDetailsBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = appList[position]
        holder.binding.tvAppName.text = item.appName
        holder.binding.tvAppName.isSelected = true
        holder.binding.tvAppPackage.text = item.packageName
        holder.binding.tvAppPackage.isSelected = true

        val drawable = BitmapDrawable(holder.binding.ivImageContact.resources, item.appIcon1)
        holder.binding.ivImageContact.setImageDrawable(drawable)
        holder.itemView.setOnClickListener {
            val selectedApp = appList[position]
            val packageName = selectedApp.packageName
            packageName?.let { it1 -> context.openAppDetails(it1) }
        }
    }

    fun setData(newData: ArrayList<AllAppListModel>) {
        appList.clear()
        appList.addAll(newData)
        notifyDataSetChanged()
    }
    override fun getItemCount(): Int = appList.size
}